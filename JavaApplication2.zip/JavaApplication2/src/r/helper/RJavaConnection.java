/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package r.helper;

/**
 *
 * @author Prabodh Saxena
 */
import model.util.RAlgoBean;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import java.io.File;
import org.rosuda.REngine.REXP;

public class RJavaConnection {

    public boolean makeConnection() {
        boolean flag=false;
        RConnection connection = null;

        try {
            /* Create a connection to Rserve instance running on default port
             * 6311
             */
            RAlgoBean bean=RAlgoBean.getRAlgoBeanInstance();
            connection = new RConnection();
            /* Note four slashes (\\\\) in the path */
            //String csvfile="D://R//TestData.csv";
            RAlgoBean rBean=RAlgoBean.getRAlgoBeanInstance();
            String col=rBean.getyHeader();
            connection.eval("library(forecast)\n" +
                                    "library(tseries)\n" +
                                    "data <- read.csv(\"D://Per//AllRow.csv\")\n" +
                                    "names(data)\n" +
                                    "#########################\n" +
                                    "data1=as.matrix(data$"+col+"/1000000000)\n" +
                                    "trainingdata=ts(data1, start = c(1970), end=c(2008))\n" +
                                    "jpeg(file=\"D://R/test.jpeg\")\n" +
                                    "plot(trainingdata)\n" +
                                    "dev.off()");
            
            System.out.println("Status Code=" + "0");
            connection.close();
            flag=true;
        } catch (RserveException e) {
            e.printStackTrace();
            System.out.println("ERROR: Unable to connect ---Rserve---");
            System.out.println("ERROR: Status Code=" + "-1");
            return false;
        } //catch (REXPMismatchException e) {
            //e.printStackTrace();
        //}
        return flag;
        //GraphCanvas rg=new GraphCanvas();
        //rg.drawFrame();
    }
}

