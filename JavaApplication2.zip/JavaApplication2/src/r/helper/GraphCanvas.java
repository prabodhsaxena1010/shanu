/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package r.helper;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;

/**
 *
 * @author Prabodh Saxena
 */
public class GraphCanvas extends Canvas{
  
    public GraphCanvas drawFrame() {  
	GraphCanvas m=new GraphCanvas();  
	//JFrame f=new JFrame(); 
        //f.add(m);  
	//f.setSize(700,700);  
	//f.setVisible(true);  
        return m;
   }  
        public void paint(Graphics g) {  
  
		    Toolkit t=Toolkit.getDefaultToolkit();  
		    Image i=t.getImage("D:/R/test.jpeg");  
		    g.drawImage(i, 120,100,this);  
		      
		}  
}
