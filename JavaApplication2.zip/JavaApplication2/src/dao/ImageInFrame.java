package dao;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.*;

public class ImageInFrame extends JFrame {
    public static void main(String[] args) throws IOException {
        String path = "D:/R/test.jpeg";
        File file = new File(path);
        JPanel panel=new JPanel();
        panel.setSize(600, 400);
        BufferedImage image = ImageIO.read(file);
        Image scaledImage=image.getScaledInstance(panel.getWidth(),panel.getHeight(),Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(scaledImage));
        ImageInFrame f = new ImageInFrame();
        
        
        panel.add(label);
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().add(panel);
        f.setSize(700, 450);
        //f.pack();
        f.setLocation(400,200);
        f.setVisible(true);
    }
    
}