/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.util;

/**
 *
 * @author 
 */
public class Constants {
    public static final String VAL_CSV_PATH = "D:/Per/Validation.csv";
    public static final String ALL_CSV_PATH = "D:/Per/AllRow.csv";
    public static final String TESTING_CSV_PATH = "D:/Per/Testing.csv";
    public static final String R_GRAPH_PATH="D:/R/test.jpeg";
    public static final String BROWSE_INVALID_FILE_WARNING="";
    public static final String BROWSE_EMPTY_TEXTBOX_WARNING="Please Choose a Valid CSV File";
    public static final String SELECT_VALUE_FROM_HEADER="Please Select Value From 'List of Header'";
    public static final String Y_TEXT_EMPTY_TEXTBOX_WARNING="Please Select Y-Axis From Header";
    public static final String X_TEXT_EMPTY_TEXTBOX_WARNING="Please Select X-Axis From Header";
    public static final String VALIDATION_DATA_EMPTY_TEXTBOX_WARNING="Please Enter Percentage(%) for Validation Data";
    public static final String X_AND_Y_SHOULD_NOT_SAME_WARNING="Value For X and Y Should Not Be Same";
    public static final String P_ARIMA_EMPTY="Please enter the value for 'p' (ARIMA)";
    public static final String D_ARIMA_EMPTY="Please enter the value for 'd' (ARIMA)";
    public static final String Q_ARIMA_EMPTY="Please enter the value for 'q' (ARIMA)";
    public static final String P_CAP_ARIMA_EMPTY="Please enter the value for 'P' (ARIMA)";
    public static final String D_CAP_ARIMA_EMPTY="Please enter the value for 'D' (ARIMA)";
    public static final String Q_CAP_ARIMA_EMPTY="Please enter the value for 'Q' (ARIMA)";
    public static final String P_SARIMA_EMPTY="Please enter the value for 'p' (SARIMA)";
    public static final String D_SARIMA_EMPTY="Please enter the value for 'd' (SARIMA)";
    public static final String Q_SARIMA_EMPTY="Please enter the value for 'q' (SARIMA)";
    public static final String P_CAP_SARIMA_EMPTY="Please enter the value for 'P' (SARIMA)";
    public static final String D_CAP_SARIMA_EMPTY="Please enter the value for 'D' (SARIMA)";
    public static final String Q_CAP_SARIMA_EMPTY="Please enter the value for 'Q' (SARIMA)";
    public static final String ALGO_SELECTION_CONFIRMATION="Are you sure, you want to continue without algotithm?";
}
