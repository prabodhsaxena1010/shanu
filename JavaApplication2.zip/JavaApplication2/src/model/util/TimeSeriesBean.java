package model.util;
import java.util.List;
import javax.swing.JList;

public class TimeSeriesBean {

	private int indexX;
	private int indexY;
        private String y_Header;
        private String x_Header;

    
	private List<String[]> rowList;
	private long allRowCount;
	private int validationPer;
	private String valCSVPath = "D:/Per/Validation.csv";
	private String allCSVPath = "D:/Per/AllRow.csv";
	private String testingCSVPath = "D:/Per/Testing.csv";
	private String parentCSVFile;
	private String test;
        private JList jList;

        public String getY_Header() {
        return y_Header;
    }

    public void setY_Header(String y_Header) {
        this.y_Header = y_Header;
    }

    public String getX_Header() {
        return x_Header;
    }

    public void setX_Header(String x_Header) {
        this.x_Header = x_Header;
    }
    public JList getjList() {
        return jList;
    }

    public void setjList(JList jList) {
        this.jList = jList;
    }
	public String getTest() {
		return test;
	}
	public long getAllRowCount() {
		return allRowCount;
	}
	public void setAllRowCount(long allRowCount) {
		this.allRowCount = allRowCount;
	}
	public int getValidationPer() {
		return validationPer;
	}
	public void setValidationPer(int validationPer) {
		this.validationPer = validationPer;
	}
	public void setTest(String test) {
		this.test = test;
	}
	public int getIndexX() {
		return indexX;
	}
	public void setIndexX(int indexX) {
		this.indexX = indexX;
	}
	public int getIndexY() {
		return indexY;
	}
	public void setIndexY(int indexY) {
		this.indexY = indexY;
	}
	public List<String[]> getRowList() {
		return rowList;
	}
	public void setRowList(List<String[]> rowList) {
		this.rowList = rowList;
	}
	public String getValCSVPath() {
		return valCSVPath;
	}
	public void setValCSVPath(String valCSVPath) {
		this.valCSVPath = valCSVPath;
	}
	public String getAllCSVPath() {
		return allCSVPath;
	}
	public void setAllCSVPath(String allCSVPath) {
		this.allCSVPath = allCSVPath;
	}
	public String getTestingCSVPath() {
		return testingCSVPath;
	}
	public void setTestingCSVPath(String testingCSVPath) {
		this.testingCSVPath = testingCSVPath;
	}
	public String getParentCSVFile() {
		return parentCSVFile;
	}
	public void setParentCSVFile(String parentCSVFile) {
		this.parentCSVFile = parentCSVFile;
	}
}
