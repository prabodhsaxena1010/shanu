/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.util;

/**
 *
 * @author Prabodh Saxena
 */
public class RAlgoBean {
    //ARIMA
    private String algoNameARIMA;
    private int pARIMA;
    private int qARIMA;
    private int dARIMA;
    private int pCapARIMA;
    private int qCapARIMA;
    private int dCapARIMA;
    private String arimaRMSE;
    private String arimaMAE;
    private String arimaMPE;
    private String arimaMADE;
    private String arimaME;
    private String sarimaRMSE;
    //SARIMA
    private String algoNameSARIMA;
    private int pSARIMA;
    private int qSARIMA;
    private int dSARIMA;
    private int pCapSARIMA;
    private int qCapSARIMA;
    private int dCapSARIMA;
    private String sarimaMAE;
    private String sarimaMPE;
    private String sarimaMADE;
    private String sarimaME;
    private String algorithm;
    
    private String yHeader;

    public int getpSARIMA() {
        return pSARIMA;
    }

    public void setpSARIMA(int pSARIMA) {
        this.pSARIMA = pSARIMA;
    }

    public int getqSARIMA() {
        return qSARIMA;
    }

    public void setqSARIMA(int qSARIMA) {
        this.qSARIMA = qSARIMA;
    }

    public int getdSARIMA() {
        return dSARIMA;
    }

    public void setdSARIMA(int dSARIMA) {
        this.dSARIMA = dSARIMA;
    }

    public int getpCapSARIMA() {
        return pCapSARIMA;
    }

    public void setpCapSARIMA(int pCapSARIMA) {
        this.pCapSARIMA = pCapSARIMA;
    }

    public int getqCapSARIMA() {
        return qCapSARIMA;
    }

    public void setqCapSARIMA(int qCapSARIMA) {
        this.qCapSARIMA = qCapSARIMA;
    }

    public int getdCapSARIMA() {
        return dCapSARIMA;
    }

    //SARIMA
    public void setdCapSARIMA(int dCapSARIMA) {
        this.dCapSARIMA = dCapSARIMA;
    }
   

    //private RAlgoBean(){}
    public static RAlgoBean getRAlgoBeanInstance(){
        return rAlgoBeanTnstance;
    }
     /*public static RAlgoBean getrAlgoBeanTnstance() {
        return rAlgoBeanTnstance;
    }

    public static void setrAlgoBeanTnstance(RAlgoBean rAlgoBeanTnstance) {
        RAlgoBean.rAlgoBeanTnstance = rAlgoBeanTnstance;
    }*/
    //Singleton
    private static RAlgoBean rAlgoBeanTnstance=new RAlgoBean();
    
    
    public int getDARIMA() {
        return dARIMA;
    }

    public void setDARIMA(int d) {
        this.dARIMA = d;
    }

    public int getdCapARIMA() {
        return dCapARIMA;
    }

    public void setdCapARIMA(int dCap) {
        this.dCapARIMA = dCap;
    }
    public String getArimaRMSE() {
        return arimaRMSE;
    }

    public void setArimaRMSE(String arimaRMSE) {
        this.arimaRMSE = arimaRMSE;
    }

    public String getArimaMAE() {
        return arimaMAE;
    }

    public void setArimaMAE(String arimaMAE) {
        this.arimaMAE = arimaMAE;
    }

    public String getArimaMPE() {
        return arimaMPE;
    }

    public void setArimaMPE(String arimaMPE) {
        this.arimaMPE = arimaMPE;
    }

    public String getArimaMADE() {
        return arimaMADE;
    }

    public void setArimaMADE(String arimaMADE) {
        this.arimaMADE = arimaMADE;
    }

    public String getArimaME() {
        return arimaME;
    }

    public void setArimaME(String arimaME) {
        this.arimaME = arimaME;
    }
    
    public String getSarimaRMSE() {
        return sarimaRMSE;
    }

    public void setSarimaRMSE(String sarimaRMSE) {
        this.sarimaRMSE = sarimaRMSE;
    }

    public String getSarimaMAE() {
        return sarimaMAE;
    }

    public void setSarimaMAE(String sarimaMAE) {
        this.sarimaMAE = sarimaMAE;
    }

    public String getSarimaMPE() {
        return sarimaMPE;
    }

    public void setSarimaMPE(String sarimaMPE) {
        this.sarimaMPE = sarimaMPE;
    }

    public String getSarimaMADE() {
        return sarimaMADE;
    }

    public void setSarimaMADE(String sarimaMADE) {
        this.sarimaMADE = sarimaMADE;
    }

    public String getSarimaME() {
        return sarimaME;
    }

    public void setSarimaME(String sarimaME) {
        this.sarimaME = sarimaME;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public int getPARIMA() {
        return pARIMA;
    }

    public void setPARIMA(int p) {
        this.pARIMA = p;
    }

    public int getQARIMA() {
        return qARIMA;
    }

    public void setQARIMA(int q) {
        this.qARIMA = q;
    }

    public int getpCapARIMA() {
        return pCapARIMA;
    }

    public void setpCapARIMA(int pCap) {
        this.pCapARIMA = pCap;
    }

    public int getqCapARIMA() {
        return qCapARIMA;
    }

    public void setqCapARIMA(int qCap) {
        this.qCapARIMA = qCap;
    }
   public String getAlgoNameARIMA() {
        return algoNameARIMA;
    }

    public void setAlgoNameARIMA(String algoNameARIMA) {
        this.algoNameARIMA = algoNameARIMA;
    }

    public String getAlgoNameSARIMA() {
        return algoNameSARIMA;
    }

    public void setAlgoNameSARIMA(String algoNameSARIMA) {
        this.algoNameSARIMA = algoNameSARIMA;
    }

    public String getyHeader() {
        return yHeader;
    }

    public void setyHeader(String yHeader) {
        this.yHeader = yHeader;
    }
    
   }
